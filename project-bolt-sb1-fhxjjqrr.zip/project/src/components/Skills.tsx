import { Code, Brain, Globe, Zap } from 'lucide-react';

export default function Skills() {
  const skillCategories = [
    {
      title: 'Programming Languages',
      icon: Code,
      color: 'from-cyan-500 to-blue-500',
      skills: [
        { name: 'Python', level: 90 },
        { name: 'JavaScript', level: 85 },
        { name: 'HTML/CSS', level: 90 },
      ]
    },
    {
      title: 'AI & Machine Learning',
      icon: Brain,
      color: 'from-blue-500 to-violet-500',
      skills: [
        { name: 'Generative AI', level: 80 },
        { name: 'Neural Networks', level: 75 },
        { name: 'Machine Learning', level: 85 },
      ]
    },
    {
      title: 'Web Development',
      icon: Globe,
      color: 'from-violet-500 to-pink-500',
      skills: [
        { name: 'React', level: 80 },
        { name: 'Frontend Development', level: 85 },
        { name: 'Responsive Design', level: 88 },
      ]
    },
    {
      title: 'Tools & Technologies',
      icon: Zap,
      color: 'from-pink-500 to-orange-500',
      skills: [
        { name: 'Git & GitHub', level: 85 },
        { name: 'TensorFlow/PyTorch', level: 75 },
        { name: 'REST APIs', level: 80 },
      ]
    }
  ];

  return (
    <section id="skills" className="py-20 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-cyan-600 font-mono text-sm tracking-wider">What I Know</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">Skills & Expertise</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mt-4"></div>
        </div>

        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-slate-200"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`p-4 bg-gradient-to-r ${category.color} rounded-xl shadow-lg`}>
                  <category.icon className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900">{category.title}</h3>
              </div>

              <div className="space-y-6">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-2">
                      <span className="text-slate-700 font-medium">{skill.name}</span>
                      <span className="text-cyan-600 font-semibold">{skill.level}%</span>
                    </div>
                    <div className="h-3 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full bg-gradient-to-r ${category.color} rounded-full transition-all duration-1000 ease-out`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 max-w-4xl mx-auto">
          <div className="bg-gradient-to-r from-cyan-500 to-blue-600 p-8 rounded-2xl shadow-xl text-white">
            <h3 className="text-2xl font-bold mb-4 text-center">Additional Competencies</h3>
            <div className="grid md:grid-cols-3 gap-6 mt-6">
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">3+</div>
                <div className="text-cyan-100">Languages</div>
                <div className="text-sm text-cyan-200 mt-1">English, Telugu, Hindi</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">5+</div>
                <div className="text-cyan-100">Sports</div>
                <div className="text-sm text-cyan-200 mt-1">Team & Individual Sports</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold mb-2">4+</div>
                <div className="text-cyan-100">Projects</div>
                <div className="text-sm text-cyan-200 mt-1">Completed & Deployed</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

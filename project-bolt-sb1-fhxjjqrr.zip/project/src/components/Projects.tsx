import { ShoppingCart, Palette, CheckSquare, Flower2, ExternalLink, Github } from 'lucide-react';

export default function Projects() {
  const projects = [
    {
      title: 'E-Commerce Platform',
      description: 'A full-featured online shopping platform with product catalog, shopping cart, user authentication, and payment integration. Built with modern web technologies for a seamless shopping experience.',
      icon: ShoppingCart,
      tags: ['React', 'JavaScript', 'Web Development', 'Full-Stack'],
      color: 'from-cyan-500 to-blue-500',
      gradient: 'from-cyan-50 to-blue-50'
    },
    {
      title: 'Neural Style Transfer',
      description: 'An AI-powered application that applies the artistic style of one image to the content of another using deep learning. Implements neural networks for creative image transformation.',
      icon: Palette,
      tags: ['Python', 'Deep Learning', 'AI', 'Computer Vision'],
      color: 'from-blue-500 to-violet-500',
      gradient: 'from-blue-50 to-violet-50'
    },
    {
      title: 'Interactive To-Do List App',
      description: 'A feature-rich task management application with priority levels, categories, and deadline tracking. Provides an intuitive interface for organizing daily tasks efficiently.',
      icon: CheckSquare,
      tags: ['JavaScript', 'Web Development', 'UI/UX'],
      color: 'from-violet-500 to-pink-500',
      gradient: 'from-violet-50 to-pink-50'
    },
    {
      title: 'Iris Classification System',
      description: 'A machine learning project that classifies iris flowers into different species based on their physical characteristics. Demonstrates practical application of ML algorithms.',
      icon: Flower2,
      tags: ['Python', 'Machine Learning', 'Data Science'],
      color: 'from-pink-500 to-orange-500',
      gradient: 'from-pink-50 to-orange-50'
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-cyan-600 font-mono text-sm tracking-wider">My Work</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">Featured Projects</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mt-4"></div>
          <p className="text-slate-600 mt-4 max-w-2xl mx-auto">
            A collection of projects showcasing my expertise in AI, machine learning, and web development
          </p>
        </div>

        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <div
              key={index}
              className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 border border-slate-200 overflow-hidden"
            >
              <div className={`h-2 bg-gradient-to-r ${project.color}`}></div>

              <div className="p-8">
                <div className="flex items-start justify-between mb-4">
                  <div className={`p-4 bg-gradient-to-r ${project.color} rounded-xl shadow-lg transform group-hover:scale-110 transition-transform`}>
                    <project.icon className="text-white" size={32} />
                  </div>
                  <div className="flex gap-2">
                    <button className="p-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                      <Github size={20} className="text-slate-700" />
                    </button>
                    <button className="p-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors">
                      <ExternalLink size={20} className="text-slate-700" />
                    </button>
                  </div>
                </div>

                <h3 className="text-2xl font-bold text-slate-900 mb-3 group-hover:text-cyan-600 transition-colors">
                  {project.title}
                </h3>

                <p className="text-slate-600 leading-relaxed mb-6">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag, tagIndex) => (
                    <span
                      key={tagIndex}
                      className={`px-3 py-1 bg-gradient-to-r ${project.gradient} text-slate-700 text-sm font-medium rounded-full border border-slate-200`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-slate-600 mb-4">Interested in seeing more of my work?</p>
          <a
            href="https://github.com"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-3 bg-slate-900 hover:bg-cyan-600 text-white rounded-lg font-medium transition-all transform hover:scale-105"
          >
            <Github size={20} />
            View More on GitHub
          </a>
        </div>
      </div>
    </section>
  );
}

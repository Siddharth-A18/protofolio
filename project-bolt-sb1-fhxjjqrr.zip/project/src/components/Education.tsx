import { GraduationCap, Calendar, MapPin } from 'lucide-react';

export default function Education() {
  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-cyan-600 font-mono text-sm tracking-wider">Academic Background</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">Education</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mt-4"></div>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-cyan-500 to-blue-500 hidden md:block"></div>

            <div className="relative bg-white p-8 rounded-2xl shadow-xl border-2 border-cyan-500/20 hover:border-cyan-500/50 transition-all transform hover:scale-105 duration-300">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 p-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full shadow-lg">
                <GraduationCap className="text-white" size={32} />
              </div>

              <div className="pt-8">
                <div className="text-center mb-6">
                  <h3 className="text-2xl md:text-3xl font-bold text-slate-900 mb-2">
                    Bachelor of Technology
                  </h3>
                  <p className="text-xl text-cyan-600 font-semibold mb-3">
                    Computer Science Engineering - Artificial Intelligence
                  </p>
                  <div className="flex flex-wrap justify-center gap-4 text-slate-600">
                    <div className="flex items-center gap-2">
                      <MapPin size={18} className="text-cyan-500" />
                      <span>Parul University</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar size={18} className="text-cyan-500" />
                      <span>2022 - 2026</span>
                    </div>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-6 mt-8">
                  <div className="bg-gradient-to-br from-cyan-50 to-blue-50 p-6 rounded-xl">
                    <h4 className="font-semibold text-slate-900 mb-3">Key Focus Areas</h4>
                    <ul className="space-y-2 text-slate-600">
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                        <span>Artificial Intelligence & Machine Learning</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                        <span>Deep Learning & Neural Networks</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                        <span>Data Structures & Algorithms</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-cyan-500 rounded-full"></div>
                        <span>Web Technologies</span>
                      </li>
                    </ul>
                  </div>

                  <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-6 rounded-xl">
                    <h4 className="font-semibold text-slate-900 mb-3">Achievements</h4>
                    <ul className="space-y-2 text-slate-600">
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                        <span>Multiple AI/ML Project Implementations</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                        <span>Full-Stack Web Development</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                        <span>Active Sports Participant</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                        <span>Strong Leadership & Team Skills</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

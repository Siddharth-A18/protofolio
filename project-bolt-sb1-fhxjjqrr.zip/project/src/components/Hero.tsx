import { Github, Linkedin, Mail, Code2 } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAxMCAwIEwgMCAwIDAgMTAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-40"></div>

      <div className="container mx-auto px-6 z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-12">
          <div className="flex-1 space-y-6 animate-fade-in">
            <div className="inline-block">
              <span className="text-cyan-400 font-mono text-sm tracking-wider">Hello, I'm</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-white via-cyan-200 to-blue-400 bg-clip-text text-transparent leading-tight">
              S.G.V.S.Siddhardha
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 font-light">
              AI & Web Development Enthusiast
            </p>
            <p className="text-lg text-slate-400 max-w-2xl leading-relaxed">
              Computer Science Engineering student specializing in Artificial Intelligence,
              passionate about building intelligent solutions and modern web applications.
            </p>

            <div className="flex gap-4 pt-4">
              <a href="#contact" className="px-8 py-3 bg-cyan-500 hover:bg-cyan-600 text-white rounded-lg font-medium transition-all transform hover:scale-105 hover:shadow-lg hover:shadow-cyan-500/50">
                Get In Touch
              </a>
              <a href="#projects" className="px-8 py-3 border-2 border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 rounded-lg font-medium transition-all transform hover:scale-105">
                View Projects
              </a>
            </div>

            <div className="flex gap-4 pt-6">
              <a href="https://github.com/Siddharth-A18" target="_blank" rel="noopener noreferrer"
                className="p-3 bg-slate-800 hover:bg-cyan-500 rounded-lg transition-all transform hover:scale-110 hover:shadow-lg">
                <Github size={24} />
              </a>
              <a href="https://www.linkedin.com/in/s-g-v-s-siddhardha-388282267?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" target="_blank" rel="noopener noreferrer"
                className="p-3 bg-slate-800 hover:bg-cyan-500 rounded-lg transition-all transform hover:scale-110 hover:shadow-lg">
                <Linkedin size={24} />
              </a>
              <a href="mailto:sgvssiddhardha@gmail.com"
                className="p-3 bg-slate-800 hover:bg-cyan-500 rounded-lg transition-all transform hover:scale-110 hover:shadow-lg">
                <Mail size={24} />
              </a>
            </div>
          </div>

          <div className="flex-shrink-0 animate-float">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl blur-2xl opacity-30 animate-pulse"></div>
              <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-2xl overflow-hidden border-4 border-cyan-500/30 shadow-2xl transform hover:scale-105 transition-transform duration-300">
                <img
                  src="/profile_pic.jpeg"
                  alt="S.G.V.S.Siddhardha"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-cyan-500 rounded-lg p-4 shadow-xl">
                <Code2 size={32} className="text-white" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <a href="#about" className="flex flex-col items-center gap-2 text-slate-400 hover:text-cyan-400 transition-colors">
          <span className="text-sm font-mono">Scroll Down</span>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </a>
      </div>
    </section>
  );
}

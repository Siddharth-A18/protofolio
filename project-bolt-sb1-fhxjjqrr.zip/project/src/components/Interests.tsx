import { Trophy, Languages, Heart } from 'lucide-react';

export default function Interests() {
  const sports = [
    { name: 'Basketball', emoji: '🏀' },
    { name: 'Cricket', emoji: '🏏' },
    { name: 'Volleyball', emoji: '🏐' },
    { name: 'Tennis', emoji: '🎾' },
    { name: 'Hockey', emoji: '🏑' }
  ];

  const languages = [
    { name: 'English', level: 'Fluent', flag: '🇬🇧' },
    { name: 'Telugu', level: 'Native', flag: '🇮🇳' },
    { name: 'Hindi', level: 'Fluent', flag: '🇮🇳' }
  ];

  return (
    <section id="interests" className="py-20 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-cyan-600 font-mono text-sm tracking-wider">Beyond Code</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">Interests & Hobbies</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mt-4"></div>
        </div>

        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 hover:shadow-xl transition-all">
            <div className="flex items-center gap-4 mb-6">
              <div className="p-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl shadow-lg">
                <Trophy className="text-white" size={28} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Sports & Athletics</h3>
            </div>

            <p className="text-slate-600 mb-6 leading-relaxed">
              An avid sports enthusiast with a passion for both team and individual sports.
              I believe in maintaining a healthy work-life balance through physical activities.
            </p>

            <div className="grid grid-cols-2 gap-4">
              {sports.map((sport, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 p-4 bg-gradient-to-br from-cyan-50 to-blue-50 rounded-xl hover:shadow-md transition-all transform hover:scale-105"
                >
                  <span className="text-3xl">{sport.emoji}</span>
                  <span className="font-medium text-slate-700">{sport.name}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl text-white">
              <p className="text-sm leading-relaxed">
                Sports have taught me valuable lessons in teamwork, leadership, perseverance, and strategic thinking - skills that translate directly into my professional work.
              </p>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 hover:shadow-xl transition-all">
              <div className="flex items-center gap-4 mb-6">
                <div className="p-4 bg-gradient-to-r from-blue-500 to-violet-500 rounded-xl shadow-lg">
                  <Languages className="text-white" size={28} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900">Languages</h3>
              </div>

              <p className="text-slate-600 mb-6 leading-relaxed">
                Multilingual capabilities enable me to communicate effectively across diverse cultures and communities.
              </p>

              <div className="space-y-4">
                {languages.map((language, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gradient-to-br from-blue-50 to-violet-50 rounded-xl hover:shadow-md transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-3xl">{language.flag}</span>
                      <span className="font-semibold text-slate-800">{language.name}</span>
                    </div>
                    <span className="px-3 py-1 bg-white text-slate-700 text-sm font-medium rounded-full border border-slate-200">
                      {language.level}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-violet-500 to-pink-500 p-8 rounded-2xl shadow-lg text-white">
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
                  <Heart className="text-white" size={24} />
                </div>
                <h3 className="text-xl font-bold">Core Values</h3>
              </div>
              <ul className="space-y-2 text-sm leading-relaxed opacity-95">
                <li className="flex items-center gap-2">
                  <span>•</span>
                  <span>Continuous learning and self-improvement</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>•</span>
                  <span>Collaboration and teamwork</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>•</span>
                  <span>Innovation and creative problem-solving</span>
                </li>
                <li className="flex items-center gap-2">
                  <span>•</span>
                  <span>Work-life balance and holistic growth</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

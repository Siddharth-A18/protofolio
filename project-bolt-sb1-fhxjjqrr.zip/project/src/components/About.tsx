import { User, Target, Sparkles } from 'lucide-react';

export default function About() {
  return (
    <section id="about" className="py-20 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-cyan-600 font-mono text-sm tracking-wider">Get To Know Me</span>
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mt-2">About Me</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-cyan-500 to-blue-500 mx-auto mt-4"></div>
        </div>

        <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-cyan-100 rounded-lg">
                  <User className="text-cyan-600" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">Who I Am</h3>
                  <p className="text-slate-600 leading-relaxed">
                    I'm a dedicated Computer Science Engineering student at Parul University,
                    specializing in Artificial Intelligence. My journey in technology is driven by
                    curiosity and a passion for creating innovative solutions that bridge the gap
                    between human needs and technological possibilities.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow border border-slate-200">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Target className="text-blue-600" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-slate-900 mb-3">What I Do</h3>
                  <p className="text-slate-600 leading-relaxed">
                    I specialize in developing intelligent applications using modern web technologies
                    and AI frameworks. From building responsive e-commerce platforms to implementing
                    neural networks for image processing, I enjoy tackling complex problems with
                    creative solutions.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-to-br from-cyan-500 to-blue-600 p-8 rounded-2xl shadow-lg text-white">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-white/20 rounded-lg backdrop-blur-sm">
                  <Sparkles className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-3">My Vision</h3>
                  <p className="leading-relaxed opacity-95">
                    I envision a future where AI and web technologies seamlessly integrate to create
                    meaningful experiences. My goal is to contribute to this future by developing
                    applications that are not only technically sound but also user-centric and
                    accessible.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200">
              <h3 className="text-xl font-semibold text-slate-900 mb-4">Quick Facts</h3>
              <ul className="space-y-3">
                <li className="flex items-center gap-3 text-slate-600">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                  <span>Multilingual: English, Telugu, Hindi</span>
                </li>
                <li className="flex items-center gap-3 text-slate-600">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                  <span>Sports Enthusiast: Basketball, Cricket, Volleyball, Tennis, Hockey</span>
                </li>
                <li className="flex items-center gap-3 text-slate-600">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                  <span>Passionate about Gen AI and Web Development</span>
                </li>
                <li className="flex items-center gap-3 text-slate-600">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full"></div>
                  <span>Team player with strong problem-solving skills</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
